# NEXUS 360 — Banco sintético para Power BI

## Entrega
Banco SQLite NEXUS360.db e CSV por tabela em csv/. Separador vírgula, UTF-8 com BOM, decimal ponto e datas ISO YYYY-MM-DD.

## Atenção aos grãos
- fPedido: 1 pedido; fItemPedido: 1 item por pedido; fFaturamento: 1 fatura por pedido faturado; fEntrega: 1 entrega por pedido faturado.
- fContasReceber: 1 título por pedido; fDevolucao: evento de devolução; fEstoqueMensal: amostra de 200 SKUs por filial/mês, NÃO estoque integral de 15 mil SKUs.
- fOcupacaoArmazem: amostra de posições por mês, não representa ocupação integral do armazém.
- fOrcamento e fMeta: granularidade filial-mês-indicador/conta. fPrevisao: meses futuros.
- fDespesa: despesas operacionais sintéticas; não inclui todas as contas necessárias a uma DRE contábil auditável.

## Regras de cálculo
Receita = SUM(fFaturamento[ReceitaLiquida]); CMV = SUM(fFaturamento[CMV]); margem bruta = receita-CMV; margem % = DIVIDE(margem,receita).
OTIF = entregas em que NoPrazo=1 e InFull=1 / entregas.
Churn: definir janela de inatividade (sugestão: 90 dias), comparar períodos e distinguir clientes sem compras e reativados.
Desconto: já embutido no ValorLiquido dos itens. Não subtrair novamente.
Devoluções: registradas separadamente; deduzir da receita apenas na medida de receita ajustada, se aplicável.
Inadimplência: títulos não pagos e vencidos em data de corte; cuidado com DataPagamento posterior à data de corte.
Data máxima histórica = 2026-10-31. Não tratar meses posteriores como vendas realizadas.

## Limitações de consistência
Dados criados para exploração de visuais e relacionamentos, não como ERP transacional reconciliado. Estoque/movimentações não são um razão de estoque conciliado; despesas não reconciliam necessariamente com caixa; metas são cenários independentes das vendas. Os pagamentos e entregas podem ter datas truncadas ao final da série. Não afirmar acurácia preditiva real com base nesta simulação.

## Modelagem Power BI
Usar dimensões d* filtrando fatos f* em sentido único. Evitar conectar fItemPedido e fFaturamento diretamente em muitos-para-muitos: usar fPedido como ponte, ou criar dimensão de pedido (dPedido) com PedidoID único e relações 1:N. Para fItemPedido -> dCliente/dFilial/dCalendario, preferir enriquecer a fato no Power Query por PedidoID. Para calendários alternativos, usar USERELATIONSHIP ou dimensões de data role-playing.

## Páginas
Executiva: fFaturamento, fDespesa, fMeta. Comercial: fItemPedido + fPedido. Clientes: fPedido, fVisitaComercial. Logística: fEntrega. WMS: dPosicaoArmazem + fOcupacaoArmazem. Financeiro: fContasReceber/fContasPagar. Previsões: fPrevisao e fFaturamento. Calendário: dCampanha/fInteracaoCampanha/fVisitaComercial. Simulação: parâmetros DAX desconectados.

Calendário estendido até 2027-04-30 para cobrir a previsão de seis meses.
